#include "baseLayer.h"
namespace keras2cpp {
    BaseLayer::~BaseLayer() = default;
}
